﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Make sure you get rid of the namespace that is automatically generated here.
class Product
{
    //List all the columns of your table here in the same format as below.
    public string ProductID { get; set; }
    public string Manufacturer { get; set; }
    public string ProductName { get; set; }
    public string Segment { get; set; }
}
